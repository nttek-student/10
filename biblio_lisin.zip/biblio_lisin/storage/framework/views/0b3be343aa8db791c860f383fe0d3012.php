<?php $__env->startSection('content'); ?>
<div class="main-container books-container">
    <h1 class="page-title">Книги</h1>

    <div class="actions-bar">
        <a href="<?php echo e(route('items.books.create')); ?>" class="btn btn-primary">Добавить книгу</a>
    </div>

    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Название</th>
                    <th>Автор</th>
                    <th>Издательство</th>
                    <th>Тип</th>
                    <th>Год</th>
                    <th>Кол-во</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($book->id); ?></td>
                    <td><?php echo e($book->fullname); ?></td>
                    <td><?php echo e($book->author->lastname); ?> <?php echo e($book->author->firstname); ?> <?php echo e($book->author->patronymic); ?></td>
                    <td><?php echo e($book->publishing->name); ?></td>
                    <td><?php echo e($book->typeOfBook->name); ?></td>
                    <td><?php echo e($book->year_of_publish); ?></td>
                    <td><?php echo e($book->count_of_items); ?></td>
                    <td class="table-actions">
                        <a href="<?php echo e(route('items.books.edit', $book)); ?>" class="btn btn-small btn-secondary">Редактировать</a>
                        <form action="<?php echo e(route('items.books.destroy', $book)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-small btn-danger">Удалить</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/books/index.blade.php ENDPATH**/ ?>
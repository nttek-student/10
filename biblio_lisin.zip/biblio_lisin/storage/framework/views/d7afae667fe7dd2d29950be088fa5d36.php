<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <h2>Добавление группы</h2>

        <form action="<?php echo e(route('readers.groups.store')); ?>" method="POST" class="form-styled">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Название группы:</label>
                <input type="text" name="name" id="name" required maxlength="20">
            </div>

            <div class="form-buttons">
                <button type="submit" class="btn btn-primary">Сохранить</button>
                <a href="<?php echo e(route('readers.groups.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/readers/groups/create.blade.php ENDPATH**/ ?>
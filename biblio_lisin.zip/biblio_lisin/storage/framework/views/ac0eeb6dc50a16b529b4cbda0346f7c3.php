<?php $__env->startSection('content'); ?>
<div class="return-page">
    <h1>Возврат книг</h1>

    <?php if($issuedBooks->count() > 0): ?>
        <form action="<?php echo e(route('accounting.return.multiple')); ?>" method="POST" id="returnForm">
            <?php echo csrf_field(); ?>

            <div class="table-container">
                <table class="return-table">
                    <thead>
                        <tr>
                            <th>✓</th>
                            <th>ID выдачи</th>
                            <th>Книга</th>
                            <th>Читатель</th>
                            <th>Дата выдачи</th>
                            <th>Количество</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $issuedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="book_actions[]" value="<?php echo e($issue->id); ?>" class="book-checkbox">
                            </td>
                            <td><?php echo e($issue->id); ?></td>
                            <td>
                                <strong><?php echo e($issue->book->fullname); ?></strong><br>
                                <small>Автор: <?php echo e($issue->book->author->lastname); ?> <?php echo e($issue->book->author->firstname); ?></small>
                            </td>
                            <td>
                                <strong><?php echo e($issue->reader->lastname); ?> <?php echo e($issue->reader->firstname); ?> <?php echo e($issue->reader->patronymic); ?></strong><br>
                                <small>
                                    <?php if($issue->reader->type_of_reader == 'teacher'): ?>
                                        Преподаватель
                                    <?php elseif($issue->reader->type_of_reader == 'student'): ?>
                                        Студент (<?php echo e($issue->reader->group->name ?? 'Без группы'); ?>)
                                    <?php else: ?>
                                        Другое
                                    <?php endif; ?>
                                </small>
                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($issue->get_date)->format('d.m.Y')); ?></td>
                            <td><?php echo e($issue->count); ?> шт.</td>
                            <td>
                                <form action="<?php echo e(route('accounting.return.return-by-id', $issue)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn-return btn-danger">Вернуть</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="return-actions">
                <button type="button" class="btn-return btn-secondary" onclick="selectAll()">Выбрать все</button>
                <button type="button" class="btn-return btn-secondary" onclick="deselectAll()">Снять выделение</button>
                <button type="submit" id="returnSelected" class="btn-return btn-primary" disabled>Вернуть выбранные книги</button>
            </div>
        </form>
    <?php else: ?>
        <p class="empty-text">Нет выданных книг для возврата</p>
    <?php endif; ?>
</div>

<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
    </div>
</footer>

<script>
document.querySelectorAll('.book-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', updateReturnButton);
});

function updateReturnButton() {
    const checkedBoxes = document.querySelectorAll('.book-checkbox:checked');
    document.getElementById('returnSelected').disabled = checkedBoxes.length === 0;
}

function selectAll() {
    document.querySelectorAll('.book-checkbox').forEach(cb => cb.checked = true);
    updateReturnButton();
}

function deselectAll() {
    document.querySelectorAll('.book-checkbox').forEach(cb => cb.checked = false);
    updateReturnButton();
}

document.getElementById('returnForm').addEventListener('submit', function(e) {
    const count = document.querySelectorAll('.book-checkbox:checked').length;
    if (count > 0 && !confirm(`Вы уверены, что хотите вернуть ${count} книг(и)?`)) {
        e.preventDefault();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/accounting/return/index.blade.php ENDPATH**/ ?>
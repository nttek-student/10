<?php $__env->startSection('content'); ?>
<div class="form-page">
    <div class="form-card">
        <h1 class="page-title">Редактирование издательства</h1>

        <form action="<?php echo e(route('items.publishings.update', $publishing)); ?>" method="POST" class="book-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name" class="form-label">Название издательства:</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($publishing->name); ?>" required maxlength="150">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="<?php echo e(route('items.publishings.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>
</div>

<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
    </div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/publishings/edit.blade.php ENDPATH**/ ?>
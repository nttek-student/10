<?php $__env->startSection('content'); ?>
    <h1>Добавление издательства</h1>
    <form action="<?php echo e(route('items.publishings.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="name">Название:</label>
        <input type="text" name="name" id="name" required>
        <button type="submit">Сохранить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/publishings/create.blade.php ENDPATH**/ ?>
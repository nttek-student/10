<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <h2>Редактирование читателя</h2>

        <form action="<?php echo e(route('readers.readers.update', $reader)); ?>" method="POST" class="form-styled">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="lastname">Фамилия:</label>
                <input type="text" name="lastname" id="lastname" value="<?php echo e($reader->lastname); ?>" required maxlength="100">
            </div>

            <div class="form-group">
                <label for="firstname">Имя:</label>
                <input type="text" name="firstname" id="firstname" value="<?php echo e($reader->firstname); ?>" required maxlength="100">
            </div>

            <div class="form-group">
                <label for="patronymic">Отчество:</label>
                <input type="text" name="patronymic" id="patronymic" value="<?php echo e($reader->patronymic); ?>" maxlength="100">
            </div>

            <div class="form-group">
                <label for="type_of_reader">Тип читателя:</label>
                <select name="type_of_reader" id="type_of_reader" required>
                    <option value="teacher" <?php echo e($reader->type_of_reader == 'teacher' ? 'selected' : ''); ?>>Преподаватель</option>
                    <option value="student" <?php echo e($reader->type_of_reader == 'student' ? 'selected' : ''); ?>>Студент</option>
                    <option value="other" <?php echo e($reader->type_of_reader == 'other' ? 'selected' : ''); ?>>Другое</option>
                </select>
            </div>

            <div id="group_field" class="form-group" style="<?php echo e($reader->type_of_reader == 'student' ? 'display: block;' : 'display: none;'); ?>">
                <label for="group_id">Группа:</label>
                <select name="group_id" id="group_id" <?php echo e($reader->type_of_reader == 'student' ? 'required' : ''); ?>>
                    <option value="">Выберите группу</option>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($group->id); ?>" <?php echo e($reader->group_id == $group->id ? 'selected' : ''); ?>><?php echo e($group->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="can_get_books" value="1" <?php echo e($reader->can_get_books ? 'checked' : ''); ?>>
                    Может получать книги
                </label>
            </div>

            <div class="form-buttons">
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="<?php echo e(route('readers.readers.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>

<script>
document.getElementById('type_of_reader').addEventListener('change', function() {
    const groupField = document.getElementById('group_field');
    const groupSelect = document.getElementById('group_id');
    if (this.value === 'student') {
        groupField.style.display = 'block';
        groupSelect.setAttribute('required', 'required');
    } else {
        groupField.style.display = 'none';
        groupSelect.removeAttribute('required');
        groupSelect.value = '';
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/readers/readers/edit.blade.php ENDPATH**/ ?>
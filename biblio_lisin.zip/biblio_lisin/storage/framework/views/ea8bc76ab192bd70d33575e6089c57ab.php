<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="page-title">Читатели</h1>

    <div class="actions-bar">
        <a href="<?php echo e(route('readers.readers.create')); ?>" class="btn btn-primary">Добавить читателя</a>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>ФИО</th>
                <th>Тип читателя</th>
                <th>Группа</th>
                <th>Может получать книги</th>
                <th class="text-center">Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $readers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reader->lastname); ?> <?php echo e($reader->firstname); ?> <?php echo e($reader->patronymic); ?></td>
                <td>
                    <?php if($reader->type_of_reader == 'teacher'): ?>
                        Преподаватель
                    <?php elseif($reader->type_of_reader == 'student'): ?>
                        Студент
                    <?php else: ?>
                        Другое
                    <?php endif; ?>
                </td>
                <td><?php echo e($reader->group ? $reader->group->name : '-'); ?></td>
                <td><?php echo e($reader->can_get_books ? 'Да' : 'Нет'); ?></td>
                <td class="table-actions">
                    <a href="<?php echo e(route('readers.readers.edit', $reader)); ?>" class="btn btn-secondary btn-small">Редактировать</a>
                    <form action="<?php echo e(route('readers.readers.destroy', $reader)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-small" onclick="return confirm('Удалить этого читателя?')">Удалить</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/readers/readers/index.blade.php ENDPATH**/ ?>
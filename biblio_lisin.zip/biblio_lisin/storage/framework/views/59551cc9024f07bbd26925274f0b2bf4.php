<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <h2>Редактирование типа издания</h2>

        <form action="<?php echo e(route('items.types-of-books.update', $typesOfBook)); ?>" method="POST" class="form-styled">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Название типа:</label>
                <input type="text" name="name" id="name" value="<?php echo e($typesOfBook->name); ?>" required maxlength="150">
            </div>

            <div class="form-buttons">
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="<?php echo e(route('items.types-of-books.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/types-of-books/edit.blade.php ENDPATH**/ ?>
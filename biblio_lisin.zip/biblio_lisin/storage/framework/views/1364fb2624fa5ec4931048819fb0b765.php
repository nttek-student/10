<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="page-title">Типы изданий</h1>

    <div class="actions-bar">
        <a href="<?php echo e(route('items.types-of-books.create')); ?>" class="btn btn-primary">Добавить тип</a>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Название</th>
                <th class="text-center">Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($type->name); ?></td>
                <td class="table-actions">
                    <a href="<?php echo e(route('items.types-of-books.edit', $type)); ?>" class="btn btn-secondary btn-small">Редактировать</a>
                    <form action="<?php echo e(route('items.types-of-books.destroy', $type)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-small" onclick="return confirm('Удалить этот тип?')">Удалить</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/types-of-books/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="form-page">
    <div class="form-card">
        <h1 class="page-title">Редактирование автора</h1>

        <form action="<?php echo e(route('items.authors.update', $author)); ?>" method="POST" class="book-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="lastname" class="form-label">Фамилия:</label>
                <input type="text" name="lastname" id="lastname" class="form-control" value="<?php echo e($author->lastname); ?>" required maxlength="100">
            </div>

            <div class="form-group">
                <label for="firstname" class="form-label">Имя:</label>
                <input type="text" name="firstname" id="firstname" class="form-control" value="<?php echo e($author->firstname); ?>" required maxlength="100">
            </div>

            <div class="form-group">
                <label for="patronymic" class="form-label">Отчество:</label>
                <input type="text" name="patronymic" id="patronymic" class="form-control" value="<?php echo e($author->patronymic); ?>" maxlength="100">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="<?php echo e(route('items.authors.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>
</div>

<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
    </div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/authors/edit.blade.php ENDPATH**/ ?>
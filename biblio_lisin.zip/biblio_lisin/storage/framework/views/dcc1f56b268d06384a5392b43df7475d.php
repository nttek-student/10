<?php $__env->startSection('content'); ?>
<div class="main-container form-page">
    <div class="form-card">
        <h1 class="page-title">Редактирование книги</h1>

        <form action="<?php echo e(route('items.books.update', $book)); ?>" method="POST" class="book-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="fullname" class="form-label">Название:</label>
                <input type="text" name="fullname" id="fullname" value="<?php echo e($book->fullname); ?>" required maxlength="255" class="form-control">
            </div>

            <div class="form-group">
                <label for="type_of_book_id" class="form-label">Тип книги:</label>
                <select name="type_of_book_id" id="type_of_book_id" required class="form-control">
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>" <?php echo e($book->type_of_book_id == $type->id ? 'selected' : ''); ?>>
                            <?php echo e($type->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="author_id" class="form-label">Автор:</label>
                <select name="author_id" id="author_id" required class="form-control">
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($author->id); ?>" <?php echo e($book->author_id == $author->id ? 'selected' : ''); ?>>
                            <?php echo e($author->lastname); ?> <?php echo e($author->firstname); ?> <?php echo e($author->patronymic); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="publishing_id" class="form-label">Издательство:</label>
                <select name="publishing_id" id="publishing_id" required class="form-control">
                    <?php $__currentLoopData = $publishings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publishing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($publishing->id); ?>" <?php echo e($book->publishing_id == $publishing->id ? 'selected' : ''); ?>>
                            <?php echo e($publishing->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="year_of_publish" class="form-label">Год издания:</label>
                <input type="number" name="year_of_publish" id="year_of_publish" value="<?php echo e($book->year_of_publish); ?>" required min="1900" max="<?php echo e(date('Y')); ?>" class="form-control">
            </div>

            <div class="form-group">
                <label for="count_of_sheets" class="form-label">Количество страниц:</label>
                <input type="number" name="count_of_sheets" id="count_of_sheets" value="<?php echo e($book->count_of_sheets); ?>" required min="1" class="form-control">
            </div>

            <div class="form-group">
                <label for="count_of_items" class="form-label">Количество экземпляров:</label>
                <input type="number" name="count_of_items" id="count_of_items" value="<?php echo e($book->count_of_items); ?>" required min="1" class="form-control">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Обновить</button>
                <a href="<?php echo e(route('items.books.index')); ?>" class="btn btn-secondary">Отмена</a>
            </div>
        </form>
    </div>

    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/books/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <h1 class="main-title">Главный экран - Библиотечный медиацентр</h1>

    <div class="stats">
        <h2 class="section-title">Общая статистика</h2>
        <ul class="stats-list">
            <li>Всего книг в библиотеке: <?php echo e($totalBooks); ?></li>
            <li>Выдано книг: <?php echo e($issuedBooks); ?></li>
            <li>Доступно книг: <?php echo e($availableBooks); ?></li>
        </ul>
    </div>

    <div class="monthly-stats">
        <h2 class="section-title">Статистика за последние 3 месяца</h2>
        <?php if($monthlyStats->count() > 0): ?>
            <table class="stats-table">
                <thead>
                    <tr>
                        <th>Месяц/Год</th>
                        <th>Выдано книг</th>
                        <th>Не возвращено</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monthlyStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stat->month); ?>/<?php echo e($stat->year); ?></td>
                        <td><?php echo e($stat->issued_count); ?></td>
                        <td><?php echo e($stat->not_returned_count); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Нет данных за последние 3 месяца</p>
        <?php endif; ?>
    </div>

    <div class="quick-links">
        <h2 class="section-title">Быстрые ссылки</h2>
        <ul class="quick-links-list">
            <li><a href="<?php echo e(route('items.books.index')); ?>">Управление книгами</a></li>
            <li><a href="<?php echo e(route('items.authors.index')); ?>">Управление авторами</a></li>
            <li><a href="<?php echo e(route('readers.readers.index')); ?>">Управление читателями</a></li>
            <li><a href="<?php echo e(route('accounting.issuance.index')); ?>">Выдача книг</a></li>
            <li><a href="<?php echo e(route('accounting.return.index')); ?>">Возврат книг</a></li>
        </ul>
    </div>
    <footer class="footer">
        <div class="footer-container">
            <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
        </div>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/home.blade.php ENDPATH**/ ?>
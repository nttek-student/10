<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотечный медиацентр НТТЭК</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body class="body">

    <header class="header">
        <div class="header-container">
            <a href="<?php echo e(route('home')); ?>" class="site-title">
                <img src="<?php echo e(asset('img/nttek_logo.png')); ?>" alt="">
            </a>
            <nav class="nav-menu">
                <a href="<?php echo e(route('home')); ?>" class="nav-link">Главная</a>
                <a href="<?php echo e(route('items.books.index')); ?>" class="nav-link">Книги</a>
                <a href="<?php echo e(route('items.authors.index')); ?>" class="nav-link">Авторы</a>
                <a href="<?php echo e(route('items.publishings.index')); ?>" class="nav-link">Издательства</a>
                <a href="<?php echo e(route('items.types-of-books.index')); ?>" class="nav-link">Типы книг</a>
                <a href="<?php echo e(route('readers.groups.index')); ?>" class="nav-link">Группы</a>
                <a href="<?php echo e(route('readers.readers.index')); ?>" class="nav-link">Читатели</a>
                <a href="<?php echo e(route('accounting.issuance.index')); ?>" class="nav-link">Выдача</a>
                <a href="<?php echo e(route('accounting.return.index')); ?>" class="nav-link">Возврат</a>
            </nav>
        </div>
    </header>

    <main class="main-container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>


</body>
</html>
<?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/layouts/app.blade.php ENDPATH**/ ?>
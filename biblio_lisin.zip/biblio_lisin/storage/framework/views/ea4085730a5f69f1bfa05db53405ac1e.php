<?php $__env->startSection('content'); ?>
<div class="main-container books-container">
    <h1 class="page-title">Издательства</h1>

    <div class="actions-bar">
        <a href="<?php echo e(route('items.publishings.create')); ?>" class="btn btn-primary">Добавить издательство</a>
    </div>

    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Название</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $publishings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publishing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($publishing->name); ?></td>
                        <td class="table-actions">
                            <a href="<?php echo e(route('items.publishings.edit', $publishing)); ?>" class="btn btn-secondary btn-small">Редактировать</a>
                            <form action="<?php echo e(route('items.publishings.destroy', $publishing)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Удалить это издательство?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-small">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?php echo e(date('Y')); ?> Библиотечный медиацентр НТТЭК</p>
    </div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/pelman/Documents/biblio_lisin/resources/views/items/publishings/index.blade.php ENDPATH**/ ?>
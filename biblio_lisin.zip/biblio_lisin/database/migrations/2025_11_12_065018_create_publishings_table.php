<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('publishings', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200)->index();
            $table->timestamps();
        });
    }


    public function down(): void
    {
        Schema::dropIfExists('publishings');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('type_of_books', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('type_of_books');
    }
};
